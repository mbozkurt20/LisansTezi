package o.osman.stok_takip;

public class urunler  {
public String ad, kod, adet, aciklama;

    public urunler(String ad, String kod, String adet, String aciklama) {
        this.ad = ad;
        this.kod = kod;
        this.adet = adet;
        this.aciklama = aciklama;
    }
}
